<?php

$database_host = 'localhost';
$database_username = 'npaashhq_root';
$database_password = 'Pr@bhat08#';
$database_name = 'npaashhq_npaasengineers';
session_start();
$db = mysqli_connect($database_host, $database_username, $database_password, $database_name);
?>
